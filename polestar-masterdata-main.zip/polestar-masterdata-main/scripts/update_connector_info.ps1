param([string]$username, [string]$password, [string]$tag, [string]$baseuri = "dm-em.informaticacloud.com")

<##>
$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Content-Type", "application/json")

$body = "{
`n  `"username`": `"$username`",
`n  `"password`": `"$password`"
`n}"

$sessionUri = 'https://'+$baseuri+'/saas/public/core/v3/login' 
$response = Invoke-RestMethod $sessionUri -Method 'POST' -Headers $headers -Body $body
$sessionId = $response.userInfo.sessionId
echo "[Session] received session Id"

$headers.Add("INFA-SESSION-ID", $sessionId)

Get-ChildItem -Path Explore/ -Filter *AppConnection*.AI_CONNECTION.json -Recurse -File | ForEach-Object{
	echo "ChildItem: " $_.Name
    $path = $_.FullName -replace ".*\\Explore\\",""
	$path = $path.Replace($_.Name,"").Replace("\","/")
    $guidUri = 'https://emw1.'+$baseuri+'/saas/public/core/v3/objects?q=type==AI_CONNECTION,tag=='+$tag
    echo "[GUID] using uri"$guidUri" for receiving guid for object "$_.FullName
    $response = Invoke-RestMethod $guidUri -Method 'GET' -Headers $headers
    $guid = $response.objects[0].id
    echo "[GUID] received guid: "$guid 

    $body_update_call = "{
`n    `"connections`": [
`n        {
`n            `"guid`": {
`n                `"`$t`": `"$guid`"
`n            },
`n            `"attributes`": [
`n                {
`n                    `"key`": {
`n                        `"`$t`": `"UserName`"
`n                    },
`n                    `"value`": {
`n                        `"`$t`": `"$username`"
`n                    }
`n                },
`n
`n                  {
`n                    `"key`": {
`n                        `"`$t`": `"Password`"
`n                    },
`n                    `"value`": {
`n                        `"`$t`": `"$password`"
`n                    }
`n                }
`n            ]
`n        }
`n    ]
`n}"

$updateUri = 'https://emw1-cai.'+$baseuri+'/active-bpel/asset/v1/update?assetType=AppConnection'
echo "[UPDATE] using uri"$updateUri" and guid "$guid" for updating object "$_.FullName
$response = Invoke-RestMethod $updateUri -Method 'PUT' -Headers $headers -Body $body_update_call
$response | ConvertTo-Json
}
echo "SUCCESSFUL"
#echo $guid 


