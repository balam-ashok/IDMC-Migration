package com.parsionate.jsontools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsontocsv.parser.JSONFlattener;
import org.jsontocsv.writer.CSVWriter;

public class JsonIterator
{

  public static final String basePath = "C:\\Work\\projects\\Polestar\\";

  @SuppressWarnings( "unchecked" )
  public static void main( String[] args )
  {
    JsonIterator ji = new JsonIterator();
    JSONArray array = ji.readPartnersFromURL();
    
    LocalDate currentDate = LocalDate.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
    String formattedDate = currentDate.format(formatter);
    System.out.println("Formatted Date: " + formattedDate);
    
    // if we want to have the files split automatically in smaller packages 
	if (Arrays.stream(args).anyMatch("split"::equals)) {

		JSONArray splittedArray = new JSONArray();
		int maxLength = 1830000;
		int fileIndex = 1;		

		for (int i = 0; i < array.length(); i++) {
			if (splittedArray.toString().length() <= maxLength) {
				splittedArray.put(array.get(i));
			} else if (splittedArray.toString().length() > maxLength || i + 1 == array.length()) {
				try {
					String fileIndexString = fileIndex < 10 ? "0" + fileIndex : Integer.toString(fileIndex);
					ji.writeJsonFile(basePath + "rdm_full_extract_" + formattedDate + "_" + fileIndexString + ".json", splittedArray);
				} catch (Exception e) {
					// do nothing
				}
				splittedArray = new JSONArray();
				fileIndex++;
			}
		}
	}
	
	// always taking the full extract into one file
	try {
		ji.writeJsonFile(basePath + "rdm_full_extract_" + formattedDate + ".json", array);
	} catch (Exception e) {
		// do nothing
	}

  }

  private void flattenJsonToCSV( File jsonFile )
  {
    List<Map<String, String>> flatJson = JSONFlattener.parseJson( jsonFile, "UTF-8" );
    CSVWriter.writeToFile(CSVWriter.getCSV(flatJson, ";"), jsonFile.getParent()+"\\"+jsonFile.getName().replace( "json", "csv" ));
  }

  private JSONArray readPartnersfromFile()
  {
    JSONArray ret = null;
    try
    {

      BufferedReader in = new BufferedReader( new FileReader( "C:\\Work\\projects\\Polestar\\RDM_Extract\\20250328_AllPartners.json" ) );
      String inputLine;
      StringBuilder response = new StringBuilder();
      while ( ( inputLine = in.readLine() ) != null )
      {
        response.append( inputLine );
      }
      in.close();
      ret = new JSONArray(response.toString());

    }
    catch ( Exception e )
    {
      e.printStackTrace();
    }
    return ret;
  }

  private JSONArray readPartnersFromURL()
  {

    JSONArray allPartner = new JSONArray();

    String auth = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkNOdjBPSTNSd3FsSEZFVm5hb01Bc2hDSDJYRSJ9.eyJhdWQiOiIzZTMzNGZmZi1iNjlhLTRhM2UtOTQwNC0zZTMyZTVhMzE0NDciLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vZmE3NGVlYjctMzczYS00YzViLThjOTctNGQzMzBjZmE5ZjYwL3YyLjAiLCJpYXQiOjE3NDUzMTU3NDcsIm5iZiI6MTc0NTMxNTc0NywiZXhwIjoxNzQ1MzE5NjQ3LCJhaW8iOiJBU1FBMi84WkFBQUF5WG9CTDRMMjgvTzJYUnpWR0RXc0Fack5jM3dVOXpUQ245ZEY5aXZ5YXBZPSIsImF6cCI6IjA5ZDU4MzAyLTFjMTUtNDQ5Yy1iMDcxLWQzNzVlZDE0YzBjNiIsImF6cGFjciI6IjEiLCJvaWQiOiI3OWQ5MWFjYy0yYmRlLTQxOWMtYTRlNS1mNGEyNmU0NWI4OTkiLCJyaCI6IjEuQVR3QXQtNTAtam8zVzB5TWwwMHpEUHFmWVA5UE16NmF0ajVLbEFRLU11V2pGRWM4QUFBOEFBLiIsInJvbGVzIjpbInJlYWQuY29tbWVyY2lhbC1wYXJ0bmVyIl0sInN1YiI6Ijc5ZDkxYWNjLTJiZGUtNDE5Yy1hNGU1LWY0YTI2ZTQ1Yjg5OSIsInRpZCI6ImZhNzRlZWI3LTM3M2EtNGM1Yi04Yzk3LTRkMzMwY2ZhOWY2MCIsInV0aSI6Im1RRzNQZUVJNlVPX3NkdE5UNGNiQUEiLCJ2ZXIiOiIyLjAifQ.d5m_jJ5YU_WhBEbNGamAek_plaLcUBfppVxx_KQtaJxDsr-0fEshUbOtBRfwM8853va1rKyHQoTWvOc8f3acNcu4xICKtnjFGtrhgMPfDbfNaHY-NYjlptmZcz9x4UC5LsvSmn3pUlM4jHAomNOIh_DzjTp-gM-nlnpqak8wX3oKMbbLTf8D2o-fX57LR4XY-PLpj_SiSTANzeNXOhws7lo3g89yxOYc41BJIro5UVirpdO1yNrWtr4dyRDK6MggiZnpPHpImCZiGoAoiayVoQo-QV6cHJj_QX7Dv51FwO13bhWWW2KtGLCUnxlovmDkW0uny9OPKGDtS7871X8puA";
//    byte[] encodedAuth = Base64.getEncoder()
//                               .encode( auth.getBytes( StandardCharsets.UTF_8 ) );
//    String authHeaderValue = "Bearer " + new String( encodedAuth );
    String authHeaderValue = "Bearer " + auth;

    String baseUrl = "https://ps-volvo-cars-api-noijyy.m3jzw3-2.deu-c1.cloudhub.io/commercial-partner?filter=&continuationToken=";
    
    try
    {
      String hasNextPage = "true";
      String nextToken = "";

      while ( "true".equals( hasNextPage ) )
      {

        URL muleUrl = new URL( baseUrl + nextToken );
        HttpURLConnection con = ( HttpURLConnection ) muleUrl.openConnection();
        con.setRequestMethod( "GET" );
        con.setRequestProperty( "User-Agent",
                                "Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:27.0) Gecko/20100101 Firefox/27.0.2 Waterfox/27.0" );
        con.setRequestProperty( "Content-Type", "application/json" );
        con.setRequestProperty( "charset", StandardCharsets.UTF_8.toString() );
        con.setRequestProperty( "Accept", "*/*" );
        con.setRequestProperty( "Accept-Encoding", "gzip, deflate, br" );
        con.setRequestProperty( "Authorization", authHeaderValue );
        System.out.println( "Fetching Page : " + muleUrl.toString() );

        BufferedReader in = new BufferedReader( new InputStreamReader( con.getInputStream() ) );
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ( ( inputLine = in.readLine() ) != null )
        {
          response.append( inputLine );
        }
        in.close();
        con.disconnect();

        JSONObject resultJson = new JSONObject( response.toString() );
        allPartner = mergeMultiJsonArray( allPartner, resultJson.getJSONArray( "partnerOrganizationalUnit" ) );

        hasNextPage = con.getHeaderField( "has-next-page" );
        nextToken = con.getHeaderField( "continuation-token" );

      }
    }
    catch ( Exception e )
    {
      e.printStackTrace();

    }
    return allPartner;

  }

  @SuppressWarnings( "unchecked" )
  public File[] splitJsonToFiles( JSONArray jsonArray )
  {
    JSONArray baseData = new JSONArray();
    JSONArray partnerLegalEntityData = new JSONArray();
    JSONArray distributionPointsData = new JSONArray();
    JSONArray partnerOrganizationalUnitFacilitiesData = new JSONArray();
    JSONArray capabilityData = new JSONArray();

    for ( int i = 0; i < jsonArray.length(); i++ )
    {
      JSONObject obj = jsonArray.getJSONObject( i );
      Iterator< String > keys = obj.keys();
      String partnerId = obj.getString( "partnerId" );
      JSONObject tmpObj = new JSONObject();
      while ( keys.hasNext() )
      {
        String key = keys.next();
        if ( key.equals( "partnerLegalEntity" ) )
        {
          if ( obj.get( key ) instanceof JSONObject )
          {
            JSONObject tObj = ( JSONObject ) obj.get( key );
            tObj.put( "partnerId", partnerId );
            partnerLegalEntityData.put( tObj );
          }
        }
        else if ( key.equals( "distributionPoints" ) )
        {
          JSONArray tObj = ( JSONArray ) obj.get( key );
          for(JSONObject jsonObject : gatherObjects( tObj, partnerId ) )
          {
            distributionPointsData.put(jsonObject );
          }
        }
        else if ( key.equals( "partnerOrganizationalUnitFacilities" ) )
        {
          JSONArray tObj = ( JSONArray ) obj.get( key );
          //Capabilities
          JSONArray[] split = extractFromArray( tObj, "capabilities", partnerId );
          JSONArray capabilityArray = split[ 0 ];
          JSONArray strippedArray = split[ 1 ];

          String facilityID = UUID.randomUUID()
                                  .toString();
          for(JSONObject jsonObject : gatherObjects( capabilityArray.getJSONArray( 0 ), partnerId, facilityID ) )
          {
            capabilityData.put(jsonObject );
          }
          
          for(JSONObject jsonObject : gatherObjects( strippedArray, partnerId, facilityID ) )
          {
            partnerOrganizationalUnitFacilitiesData.put(jsonObject );
          }

        }
        else
        {
          tmpObj.put( key, obj.get( key ) );
        }
      } //while
      baseData.put( tmpObj );
    }

    File[] jsonFiles = new File[5];

    try
    {
      jsonFiles[ 0 ] = writeJsonFile( basePath + "BaseData.json", baseData );
      jsonFiles[ 1 ] = writeJsonFile( basePath + "partnerLegalEntityData.json", partnerLegalEntityData );
      jsonFiles[ 2 ] = writeJsonFile( basePath + "distributionPoints.json", distributionPointsData );
      jsonFiles[ 3 ] = writeJsonFile( basePath + "partnerOrganizationalUnitFacilities.json", partnerOrganizationalUnitFacilitiesData );
      jsonFiles[ 4 ] = writeJsonFile( basePath + "capabilities.json", capabilityData );

    }
    catch ( FileNotFoundException | UnsupportedEncodingException e )
    {
      e.printStackTrace();

    }
    return jsonFiles;

  }

  private File writeJsonFile( String path, JSONArray array ) throws FileNotFoundException, UnsupportedEncodingException
  {
    File f = new File( path );
    PrintWriter jsonWriter = new PrintWriter( path, "UTF-8" );
    jsonWriter.write( array.toString() );
    jsonWriter.close();
    return f;
  }

  @SuppressWarnings( "unchecked" )
  private JSONArray[] extractFromArray( JSONArray jsonArray, String subArrayName, String partnerId )
  {
    JSONArray subArray = new JSONArray();
    JSONArray restArray = new JSONArray();

    for ( int i = 0; i < jsonArray.length(); i++ )
    {
      JSONObject obj = jsonArray.getJSONObject( i );
      Iterator< String > keys = obj.keys();

      JSONObject tmpObj = new JSONObject();
      while ( keys.hasNext() )
      {
        String key = keys.next();
        if ( key.equals( subArrayName ) )
        {
          JSONArray tObj = ( JSONArray ) obj.get( key );
          subArray.put( gatherObjects( tObj, partnerId ) );
        }
        else
        {
          tmpObj.put( key, obj.get( key ) );
        }
      } //while
      restArray.put( tmpObj );
    }
    return new JSONArray[] { subArray, restArray };
  }

  private List< JSONObject > gatherObjects( JSONArray array, String partnerId, String parentId )
  {
    ArrayList< JSONObject > al = new ArrayList< JSONObject >();

    for ( int i = 0; i < array.length(); i++ )
    {
      JSONObject obj = array.getJSONObject( i );
      obj.put( "partnerID", partnerId );
      if ( !"".equals( parentId ) )
      {
        obj.put( "facilityID", parentId );
      }
      al.add( obj );
    }
    return al;
  }

  private List< JSONObject > gatherObjects( JSONArray array, String partnerId )
  {
    return gatherObjects( array, partnerId, "" );
  }

  public static JSONArray mergeMultiJsonArray( JSONArray... arrays )
  {
    JSONArray outArray = new JSONArray();
    for ( JSONArray array : arrays )
    {
      for ( int i = 0; i < array.length(); i++ )
      {
        outArray.put( array.optJSONObject( i ) );
      }
    }
    return outArray;
  }

}
