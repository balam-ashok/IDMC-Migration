#!/bin/bash

for file in S4/*.xlsx; do
    # Extract the base name without extension
    base_name="${file%.*}"

    # Check if the base name contains an underscore
    if [[ "$base_name" == *"_"* ]]; then
        # Split at the first underscore
        sap_table="${base_name%%_*}"

        # Only proceed if SAP table name is not empty
        if [[ -n "$sap_table" ]]; then
            new_name="${sap_table}.xlsx"

            # Rename with confirmation prompt
            mv -f -- "$file" "$new_name"
             # echo "Renamed: $file -> $new_name"
        fi
    fi
done
