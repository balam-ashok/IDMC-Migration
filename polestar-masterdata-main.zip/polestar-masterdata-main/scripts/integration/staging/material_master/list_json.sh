#!/bin/bash
# find /home/ssm-user -maxdepth 1 -name *.json
ls -1d /integration/staging/material_master/PLM/* |grep -i \.json$ > PLM/manifest.csv
