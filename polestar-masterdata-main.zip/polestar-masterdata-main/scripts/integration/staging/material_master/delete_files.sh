#!/bin/bash

# Usage: ./script.sh --folder [VCC|PLM|S4]

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Function to display usage message
usage() {
  echo "Usage: $0 [VCC|PLM|S4]"
  exit 1
}

# Check if exactly two parameters are passed
if [[ "$#" -ne 1 ]]; then
  usage
fi


FOLDER="$1"

# Validate folder value
if [[ "$FOLDER" != "VCC" && "$FOLDER" != "PLM" && "$FOLDER" != "S4" ]]; then
  echo "Error: Invalid folder name. Valid options: VCC, PLM, S4"
  exit 1
fi

TARGET="$SCRIPT_DIR/$FOLDER"

rm -rf "$TARGET"
mkdir -p "$TARGET"
exit 0
