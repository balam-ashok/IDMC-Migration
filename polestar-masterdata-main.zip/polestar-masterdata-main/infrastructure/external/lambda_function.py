import boto3
import json

def lambda_handler(event, context):
    
    #1 Log event
    print('************ The event is: ************')
    print(event)
    
    
    #2 Read secret from secrets manager
    secret_name = "idmc/mdm/oauth-publishing-api-access"
    region_name = "eu-north-1"
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secretResponse = json.loads(get_secret_value_response['SecretString'])
    #print(secretResponse)  //hide the credentials
    
    clientidValue = event['headers']['informaticamdmclientid']
    print(clientidValue)
    
    
    #3 See if the token is valid
    auth = 'Deny'
    if secretResponse['clientid'] == clientidValue:
        auth = 'Allow'
    else:
        auth = 'Deny'
        
    #4 Construct and return the response
    authResponse = { 'principalId': 'user', 'policyDocument': { 'Version': '2012-10-17', 'Statement': [{'Action': 'execute-api:Invoke', 'Resource': 'arn:aws:execute-api:*', 'Effect': auth}] }}
    return authResponse
    
