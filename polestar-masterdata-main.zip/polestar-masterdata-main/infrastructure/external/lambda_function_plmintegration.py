import json
import boto3
import os

# Retrieve the target S3 bucket from environment variables
S3_BUCKET = os.environ.get("S3_BUCKET")
FILE_PATH = os.environ.get("PLM_JSON_PATH")
# Initialize the S3 client outside the handler for connection reuse
s3 = boto3.client('s3')


def lambda_handler(event, context):
    print("######### RECIEVED EVENT #########")
    print(F"Event: {json.dumps(event)}")
    is_error = False
    errors = list()
    for record in event.get('Records'):

        # Use the SQS message ID as the unique filename
        message_id = record.get('messageId')
        sqs_body = json.loads(record.get('body'))
        payload = json.loads(sqs_body.get('Message'))

        if not isinstance(payload, list):
            payload = [payload]

        print(f"Writing {FILE_PATH}/plm_sns_{message_id}.json with contents {json.dumps(payload)}")
        filename = f"{FILE_PATH}/plm_sns_{message_id}.json"

        # Upload the file to the specified S3 bucket
        try:
            s3.put_object(
                Bucket=S3_BUCKET,
                Key=filename,
                Body=json.dumps(payload),
                ContentType='application/json'
            )
            print(f"File {filename} uploaded successfully.")
        except Exception as e:
            is_error = True
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            errors.append(f'Failed to upload message with id {message_id} to S3 : {error_code} - {error_message}')


    ret_val = {
        'statusCode': 500 if is_error else 200,
        'body': json.dumps(errors) if is_error else json.dumps(['Files created successfully!'])
    }
    print(f"Finished. Return message: {json.dumps(ret_val)}")
    print("######### END EVENT #########")
    return ret_val
