
provider "aws" {
  region = "eu-north-1"

  default_tags {
    tags = {
      Environment = var.env
      Project     = "masterdata"
    }
  }
}

data "aws_caller_identity" "current" {}

module "dynamodb_state" {
  source = "../modules/dynamodb/state"

  account_number = data.aws_caller_identity.current.account_id
  region         = var.region

  name     = var.dynamodb_state_name
  hash_key = var.dynamodb_state_hash_key

  region_primary   = var.dynamodb_region_primary
  region_secondary = var.dynamodb_region_secondary
}
module "s3_" {
  source = "../modules/s3/state"

  bucket_name = replace(var.s3_state_bucket_name,"{env}", var.env)
}
