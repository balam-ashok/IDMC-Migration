terraform {
  # This needs to be commented out first time; after first deployment remove comments and deploy again
  backend "s3" {
    bucket  = "dev-masterdata-tf-state"
    key     = "state/terraform.tfstate"
    region  = "eu-north-1"
    profile = "DeveloperPermissions-056353309955"

    dynamodb_table = "terraform_state"

    #  Not needed for this?
    #  encrypt = true
    #  kms_key_id     = "alias/terraform-bucket-key"
  }

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 4.1"
    }
  }

  required_version = ">= 1.6.0"
}

module "eventbridge" {
  source                       = "../../modules/eventbridge_old"
  region                       = var.region
  InformaticaMDMClientId       = var.InformaticaMDMClientId
  event_rules                  = var.event_rules
  event_rule_function_mappings = var.event_rule_function_mappings
  account_id                   = var.account_id
}
resource "aws_secretsmanager_secret" "my_secret" {
  name        = "my-cross-account-secret"
  description = "Secret for cross account access"
}


provider "aws" {
  region  = "eu-north-1"
  profile = "DeveloperPermissions-056353309955"

  default_tags {
    tags = {
      Environment = var.env
      Project     = "masterdata"
    }
  }
}
