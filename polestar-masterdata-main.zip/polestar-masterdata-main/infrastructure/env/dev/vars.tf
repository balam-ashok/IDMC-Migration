variable "env" {
  description = "Environment name"
  type        = string
}

variable "region" {
  default = "eu-north-1"
}

variable "AWS_ACCESS_KEY_ID" {
  description = "AWS access key id"
  default     = ""
  sensitive   = true
}

variable "AWS_SECRET_ACCESS_KEY" {
  description = "AWS secret access key"
  default     = ""
  sensitive   = true
}

variable "InformaticaMDMClientId" {
  default   = ""
  sensitive = true
}

variable "account_id" {
  default   = ""
  sensitive = true
}

variable "event_rules" {
  description = "An object for configuring the event rules on the event bus"
  type        = map(object({
    name   = string
    detail = map(any)
  }))
}

variable "event_rule_function_mappings" {
  description = "An object for configuring the targets on the event bus"
  type        = list(object({
    rule_name     = string
    function_name = string
  }))
}
