env                    = "dev"
InformaticaMDMClientId = "f4v0GNnK0sGlbioLEZ1VsM"
account_id             = "056353309955"

event_rules = {
  rule1 = {
    name   = "MDMPublishingRuleBusinessPartner"
    detail = {
      metadata = {
        eventName = [
          "BusinessPartner"
        ]
      }
    }
  }
  rule2 = {
    name   = "MDMPublishingRuleLocation"
    detail = {
      metadata = {
        eventName = [
          "Location"
        ]
      }
    }
  }
}

event_rule_function_mappings = [
  {
    rule_name     = "MDMPublishingRuleBusinessPartner",
    function_name = "LogEventBridgeEvent"
  },
  {
    rule_name     = "MDMPublishingRuleLocation",
    function_name = "LogEventBridgeEvent"
  }
]