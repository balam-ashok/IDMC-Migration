terraform {
  backend "s3" {
    region = "eu-north-1"
    bucket = "prod-masterdata-tf-state"
    key    = "state/terraform.tfstate"
    dynamodb_table = "terraform_state"

  }

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 5.27"
    }
  }

  required_version = ">= 1.6.0"
}

provider "aws" {
  region = "eu-north-1"

  default_tags {
    tags = {
      Environment = var.env
      Project     = "masterdata"
    }
  }
}

module "ec2" {
  source = "../../../modules/ec2"
  env = var.env
  region = var.region
  ami = "ami-0b04706355ee837b1"
  availability_zone = "eu-north-1a"
  instance_type = "t3.xlarge"
  subnet_id = "subnet-04cdab3f8c210e329"
  vpc_security_groups = ["sg-0ac1e530a2974c0be"]
}
