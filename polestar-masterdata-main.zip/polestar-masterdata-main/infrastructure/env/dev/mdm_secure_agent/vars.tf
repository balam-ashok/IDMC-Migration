variable "env" {
  description = "Environment name"
  type        = string
  default = "dev"
}

variable "region" {
  default = "eu-north-1"
}

