variable "env" {
  description = "Environment name"
  type        = string
  default     = "prod"
}

variable "region" {
  default = "eu-north-1"
}

variable "ami" {
  description = "Amazon Machine Image"
  type        = string
  default     = "ami-0b04706355ee837b1"
}

variable "instance_type" {
  description = "Instance Type"
  type        = string
  default     = "t3.xlarge"
}

variable "subnet_id" {
  description = "Subnet ID"
  type        = string
  default     = "subnet-00b00301a155504d6"
}

variable "availability_zone" {
  description = "Availability zone"
  type        = string
  default     = "eu-north-1a"
}

variable "vpc_security_groups" {
  description = "VPC Security Groups"
  type        = list(string)
  default     = ["sg-0931161dbabeaf872"]
}

variable "cpu_core_count" {
  description = "Cpu cores"
  type        = number
  default     = 2
}

variable "bucket_name" {
  description = "Name of state S3 bucket"
  type        = string
  default     = "polestar-mdm-file-storage"
}

variable "bucket_directories" {
  type    = set(string)
  default = [
    "DataProfiling/MDM/BusinessPartner",
    "DataProfiling/MDM/Location",
    "DataIntegration/DATO_CMS",
    "DataIntegration/LocationDB",
    "DataIntegration/PLOT",
    "DataIntegration/PublishingInitialLoad"
  ]
}
