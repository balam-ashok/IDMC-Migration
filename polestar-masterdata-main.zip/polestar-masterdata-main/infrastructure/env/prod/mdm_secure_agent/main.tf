terraform {
  backend "s3" {
    region         = "eu-north-1"
    bucket         = "prod-masterdata-tf-state-polestar-ec2"
    key            = "state/terraform.tfstate"
    dynamodb_table = "terraform_state_polestar_ec2"

  }

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 5.27"
    }
  }

  required_version = ">= 1.6.0"
}

provider "aws" {
  region = "eu-north-1"

  default_tags {
    tags = {
      Environment = var.env
      Project     = "masterdata"
    }
  }
}

module "ec2" {
  source              = "../../../modules/ec2"
  env                 = var.env
  region              = var.region
  ami                 = var.ami
  instance_type       = var.instance_type
  subnet_id           = var.subnet_id
  availability_zone   = var.availability_zone
  vpc_security_groups = var.vpc_security_groups
  cpu_core_count      = var.cpu_core_count
}

module "s3_bucket" {
  source             = "../../../modules/s3/general"
  env                = var.env
  bucket_name        = var.bucket_name
  bucket_directories = var.bucket_directories
  ec2_role_arn       = module.ec2.ec2_role_arn
}
