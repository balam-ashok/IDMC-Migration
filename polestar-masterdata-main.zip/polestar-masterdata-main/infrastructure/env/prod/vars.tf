variable "env" {
  description = "Environment name"
  type        = string
}

variable "region" {
  default = "eu-north-1"
}

variable "AWS_ACCESS_KEY_ID" {
  description = "AWS access key id"
  default     = ""
  sensitive   = true
}

variable "AWS_SECRET_ACCESS_KEY" {
  description = "AWS secret access key"
  default     = ""
  sensitive   = true
}

variable "InformaticaMDMClientId" {
  default   = ""
  sensitive = true
}

variable "account_id" {
  default   = ""
  sensitive = true
}

variable "event_rules" {
  description = "An object for configuring the event rules on the event bus"
  type        = map(object({
    name   = string
    source = list(string)
  }))
}

variable "event_rule_function_mappings" {
  description = "An object for configuring the targets on the event bus"
  type        = list(object({
    rule_name     = string
    function_name = string
  }))
}

variable "adp_eventbus" {
  default = "arn:aws:events:eu-north-1:528720639930:event-bus/mdm-data-acquisition-prod"
}

variable "plm_sns_topic" {
  default = "arn:aws:sns:eu-central-1:859449979010:Mule_Prod_PLM_PartMaster"
}

variable "s3_bucket" {
  default = "polestar-mdm-file-storage-prod"
}

variable "s3_plm_json_path" {
  default = "DataIntegration/MaterialMaster/PLM"
}
variable "secret_manager_name" {
  default = "idmc/prod/apiconnection-secretcredential-odp"
}
variable "role_name" {
  default = "mdm-odp-secureagentread-prod-role"
}

variable "odp_account_ids" {
  description = "Account IDs for cross-account access"
  type = map(string)

  default = {
    prod  = "591626352479"
  }
}