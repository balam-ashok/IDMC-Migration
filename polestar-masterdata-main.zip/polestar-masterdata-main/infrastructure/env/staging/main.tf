terraform {
  # This needs to be commented out first time; after first deployment remove comments and deploy again
  backend "s3" {
    region         = "eu-north-1"
    #Use profile for local execution only
    #profile = "DeveloperPermissions-021607931411"
    bucket         = "staging-masterdata-tf-state"
    key            = "state/terraform.tfstate"
    dynamodb_table = "terraform_state"

  }

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 5.27"
    }
  }

  required_version = ">= 1.6.0"
}

provider "aws" {
  region     = "eu-north-1"
  #Use profile for local execution only
  #profile = "DeveloperPermissions-021607931411"
  access_key = var.AWS_ACCESS_KEY_ID
  secret_key = var.AWS_SECRET_ACCESS_KEY

  default_tags {
    tags = {
      Environment = var.env
      Project     = "masterdata"
    }
  }
}


module "eventbridge" {
  source                       = "../../modules/eventbridge"
  region                       = var.region
  InformaticaMDMClientId       = var.InformaticaMDMClientId
  event_rules                  = var.event_rules
  event_rule_function_mappings = var.event_rule_function_mappings
  account_id                   = var.account_id
  adp_eventbus                 = var.adp_eventbus
}
module "secretmanager" {
  source                       = "../../modules/secretmanager"
  region                       = var.region
  secret_manager_name          = var.secret_manager_name
  role_name                    = var.role_name
  odp_account_ids              = var.odp_account_ids
  
}

module "sqs" {
  source                       = "../../modules/sqs"
  region                       = var.region
  account_id                   = var.account_id
  plm_sns_topic                = var.plm_sns_topic
  s3_bucket                    = var.s3_bucket
  s3_plm_json_path             = var.s3_plm_json_path
}
