env                    = "staging"
InformaticaMDMClientId = "f4v0GNnK0sGlbioLEZ1VsM"
account_id             = "021607931411"

event_rules = {
  rule1 = {
    name   = "AllMessages"
    source = ["Informatica MDM"]
  }
/*  rule2 = {
    name   = "MDMPublishingRuleLocation"
    detail = {
      metadata = {
        eventName = [
          "Location"
        ]
      }
    }
  }*/
}

event_rule_function_mappings = [
  {
    rule_name     = "AllMessages",
    function_name = "LogEventBridgeEvent"
  }
/*  {
    rule_name     = "MDMPublishingRuleLocation",
    function_name = "LogEventBridgeEvent"
  }*/
]

bucket_name        = "polestar-mdm-file-storage-staging"
bucket_directories = [
  "IntegrationErrorLogs/BusinessPartnerAPI",
  "IntegrationSuccessLogs/BusinessPartnerAPI/PLOT",
  "DataProfiling/MDM/BusinessPartner",
  "DataProfiling/MDM/Location",
  "DataIntegration/DATO_CMS",
  "DataIntegration/LocationDB",
  "DataIntegration/PLOT",
  "DataIntegration/PublishingInitialLoad",
  "DataIntegration/ReferenceData",
  "DataIntegration/MaterialMaster/PLM",
  "DataIntegration/MaterialMaster/VCC",
  "DataIntegration/MaterialMaster/S4"
]
