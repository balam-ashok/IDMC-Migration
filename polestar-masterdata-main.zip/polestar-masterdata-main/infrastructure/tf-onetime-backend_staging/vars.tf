variable "env" {
  description = "AWS Enviroment"
  type = string
  default = "staging"
  
}
variable "region" {
  description = "AWS region"
  type        = string
  default     = "eu-north-1"
}
variable "dynamodb_datalake_name" {
  description = "Name of DynamoDB table for data lake"
  type        = string
  default     = "data-events-datalake"
}

variable "dynamodb_state_name" {
  description = "Name of DynamoDB table for state"
  type        = string
  default     = "terraform_state"
}

variable "dynamodb_state_hash_key" {
  description = "Table hash (primary) key"
  type        = string
  default     = "LockID"
}
variable "dynamodb_region_primary" {
  description = "Primary region"
  type        = string
  default     = "eu-north-1"
}

variable "dynamodb_region_secondary" {
  description = "Secondary region"
  type        = string
  default     = "eu-central-1" # eu-west-1?
}
variable "s3_state_bucket_name" {
  description = "Name of state S3 bucket"
  type        = string
  default     = "{env}-masterdata-tf-state"
}

variable "s3_state_bucket_arn" {
  description = "ARN of S3 bucket"
  type        = string
  default     = "arn:aws:s3:::{env}-masterdata-tf-state"
}