variable "env" {
  description = "AWS Enviroment"
  type        = string
}
variable "bucket_name" {
  description = "Name of state S3 bucket"
  type        = string
}

variable "bucket_directories" {
  type = set(string)
}

variable "ec2_role_arn" {
  description = "ARN of the EC2 role"
  type        = string
}
