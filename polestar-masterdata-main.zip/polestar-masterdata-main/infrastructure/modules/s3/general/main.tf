resource "aws_s3_bucket" "s3_bucket" {
  bucket        = "${var.bucket_name}-${var.env}"
  force_destroy = true
}

resource "aws_s3_object" "s3_bucket_directory" {
  for_each     = var.bucket_directories
  bucket       = aws_s3_bucket.s3_bucket.id
  key          = each.value
  content_type = "application/x-directory"
}

resource "aws_iam_role" "s3_bucket_role" {
  name                 = "MDMS3Access"
  max_session_duration = 2

  assume_role_policy = jsonencode({
    Version   = "2012-10-17"
    Statement = [
      {
        Action    = "sts:AssumeRole"
        Effect    = "Allow"
        Sid       = ""
        Principal = {
          AWS = var.ec2_role_arn
        }
      }
    ]
  })
}

resource "aws_iam_role_policy" "s3_role_policy" {
  name   = "s3_role_policy"
  role   = aws_iam_role.s3_bucket_role.id
  policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:*",
                "s3-object-lambda:*"
            ],
            "Resource": "*"
        }
    ]
}
EOF

}

