# Configuration for an AWS-encrypted, private and versioned S3 bucket which will store our TF state.
#
# See: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket

resource "aws_s3_bucket" "terraform_state" {
  # TODO
  #checkov:skip=CKV_AWS_18:Not necessary for demo (access logging)
  #checkov:skip=CKV_AWS_21:Not necessary for demo (versioning)
  #checkov:skip=CKV_AWS_144:Not necessary for demo (cross-region replication)
  bucket        = var.bucket_name
  force_destroy = true
}

#resource "aws_s3_bucket_acl" "bucket_acl" {
#  bucket = aws_s3_bucket.terraform_state.id
#  acl    = "private"
#}

resource "aws_s3_bucket_server_side_encryption_configuration" "sse" {
  bucket = aws_s3_bucket.terraform_state.bucket

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "block" {
  bucket = aws_s3_bucket.terraform_state.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "state_versioning" {
  bucket = aws_s3_bucket.terraform_state.id

  versioning_configuration {
    status = "Enabled"
  }
}
