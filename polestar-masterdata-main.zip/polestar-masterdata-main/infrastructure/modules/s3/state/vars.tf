variable "bucket_name" {
  description = "Name of state S3 bucket"
  type        = string
}
