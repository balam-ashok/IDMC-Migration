#
# API Gateway
#

resource "aws_apigatewayv2_api" "mdm_publishing_api_gateway" {
  name          = "MDMPublishing"
  protocol_type = "HTTP"
}

resource "aws_apigatewayv2_integration" "mdm_publishing_integration" {
  api_id              = aws_apigatewayv2_api.mdm_publishing_api_gateway.id
  integration_type    = "AWS_PROXY"
  integration_subtype = "StepFunctions-StartExecution"
  credentials_arn     = aws_iam_role.role_for_mdmpublishing.arn

  request_parameters = {
    StateMachineArn = aws_sfn_state_machine.mdm_publishing_state_machine.arn
    Input           = "$request.body"
    Region          = var.region
  }
}

resource "aws_apigatewayv2_route" "mdm-publishing_route_locations" {
  api_id             = aws_apigatewayv2_api.mdm_publishing_api_gateway.id
  route_key          = "POST /mdm-publishing/locations"
  authorization_type = "CUSTOM"
  authorizer_id      = aws_apigatewayv2_authorizer.mdm_publishing_authorizer.id
  target             = "integrations/${aws_apigatewayv2_integration.mdm_publishing_integration.id}"
}

resource "aws_apigatewayv2_route" "mdm_publishing_route_businesspartners" {
  api_id             = aws_apigatewayv2_api.mdm_publishing_api_gateway.id
  route_key          = "POST /mdm-publishing/businesspartners"
  authorization_type = "CUSTOM"
  authorizer_id      = aws_apigatewayv2_authorizer.mdm_publishing_authorizer.id
  target             = "integrations/${aws_apigatewayv2_integration.mdm_publishing_integration.id}"
}

resource "aws_apigatewayv2_route" "mdm_publishing_route_materialmaster" {
  api_id             = aws_apigatewayv2_api.mdm_publishing_api_gateway.id
  route_key          = "POST /mdm-publishing/material-master"
  authorization_type = "CUSTOM"
  authorizer_id      = aws_apigatewayv2_authorizer.mdm_publishing_authorizer.id
  target             = "integrations/${aws_apigatewayv2_integration.mdm_publishing_integration.id}"
}

resource "aws_apigatewayv2_authorizer" "mdm_publishing_authorizer" {
  api_id                            = aws_apigatewayv2_api.mdm_publishing_api_gateway.id
  name                              = "MDMPublishEventsAuthorizer"
  authorizer_type                   = "REQUEST"
  authorizer_uri                    = aws_lambda_function.mdm_publishing_authorizer_function.invoke_arn
  identity_sources                  = ["$request.header.InformaticaMDMClientId"]
  authorizer_payload_format_version = "2.0"
}


resource "aws_apigatewayv2_stage" "mdm_publishing_api_gateway_stage" {
  api_id      = aws_apigatewayv2_api.mdm_publishing_api_gateway.id
  name        = "$default"
  auto_deploy = true

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.MDMAPIGatewayLogGroup.arn
    format          = jsonencode(
      {
        httpMethod     = "$context.httpMethod"
        ip             = "$context.identity.sourceIp"
        protocol       = "$context.protocol"
        requestId      = "$context.requestId"
        requestTime    = "$context.requestTime"
        responseLength = "$context.responseLength"
        routeKey       = "$context.routeKey"
        status         = "$context.status"
        error_message  = "$context.error.message"
      }
    )
  }
}

resource "aws_cloudwatch_log_group" "MDMAPIGatewayLogGroup" {
  name_prefix       = "arn"
  retention_in_days = "3"
}

#
# Step Function
#

resource "aws_sfn_state_machine" "mdm_publishing_state_machine" {
  name       = "send-to-event-bus-state-machine"
  role_arn   = aws_iam_role.role_for_mdmpublishing.arn
  definition = <<EOF
{
	"Comment": "MDM Publishing to domain account event bridges",
	"StartAt": "Parallel",
	"States": {
		"Parallel": {
			"Type": "Parallel",
			"Branches": [
				{
					"StartAt": "EventBridge PutEvents to CAS Domain Bus",
					"States": {
						"EventBridge PutEvents to CAS Domain Bus": {
							"Type": "Task",
							"Resource": "arn:aws:states:::aws-sdk:eventbridge:putEvents",
							"Parameters": {
								"Entries": [
									{
										"Detail.$": "$",
										"DetailType.$": "States.Format('MDM_{}', $.metadata.eventName)",
										"EventBusName": "arn:aws:events:eu-north-1:260244973671:event-bus/cas-domain-bus",
										"Source": "Informatica MDM"
									}
								]
							},
							"End": true,
							"Retry": [
								{
									"ErrorEquals": [
										"States.ALL"
									],
									"BackoffRate": 3,
									"IntervalSeconds": 30,
									"MaxAttempts": 5
								}
							]
						}
					}
				},
				{
					"StartAt": "EventBridge PutEvents to ADP Eventbus",
					"States": {
						"EventBridge PutEvents to ADP Eventbus": {
							"Type": "Task",
							"Resource": "arn:aws:states:::aws-sdk:eventbridge:putEvents",
							"Parameters": {
								"Entries": [
									{
										"Detail.$": "$",
										"DetailType.$": "States.Format('MDM_{}', $.metadata.eventName)",
										"EventBusName": "${var.adp_eventbus}",
										"Source": "Informatica MDM"
									}
								]
							},
							"End": true,
							"Retry": [
								{
									"ErrorEquals": [
										"States.ALL"
									],
									"BackoffRate": 3,
									"IntervalSeconds": 30,
									"MaxAttempts": 5
								}
							]
						}
					}
				},
				{
					"StartAt": "EventBridge PutEvents to PCI Domain Bus",
					"States": {
						"EventBridge PutEvents to PCI Domain Bus": {
							"Type": "Task",
							"Resource": "arn:aws:states:::aws-sdk:eventbridge:putEvents",
							"Parameters": {
								"Entries": [
									{
										"Detail.$": "$",
										"DetailType.$": "States.Format('MDM_{}', $.metadata.eventName)",
										"EventBusName": "arn:aws:events:eu-north-1:762355295099:event-bus/pci-domain-bus",
										"Source": "Informatica MDM"
									}
								]
							},
							"End": true,
							"Retry": [
								{
									"ErrorEquals": [
										"States.ALL"
									],
									"BackoffRate": 3,
									"IntervalSeconds": 30,
									"MaxAttempts": 5
								}
							]
						}
					}
				},
				{
					"StartAt": "EventBridge PutEvents to Commerce Domain Bus",
					"States": {
						"EventBridge PutEvents to Commerce Domain Bus": {
							"Type": "Task",
							"Resource": "arn:aws:states:::aws-sdk:eventbridge:putEvents",
							"Parameters": {
								"Entries": [
									{
										"Detail.$": "$",
										"DetailType.$": "States.Format('MDM_{}', $.metadata.eventName)",
										"EventBusName": "arn:aws:events:eu-north-1:146621558172:event-bus/commerce-domain-bus",
										"Source": "Informatica MDM"
									}
								]
							},
							"End": true,
							"Retry": [
								{
									"ErrorEquals": [
										"States.ALL"
									],
									"BackoffRate": 3,
									"IntervalSeconds": 30,
									"MaxAttempts": 5
								}
							]
						}
					}
				}
			],
			"End": true
		}
	}
}
  EOF
}

/* STEP FUNCTION DEFINITION FOR 3 PARALLEL PUT EVENTS
<<EOF
{
  "Comment": "MDM Publishing to domain account event bridges",
  "StartAt": "Parallel",
  "States": {
    "Parallel": {
      "Type": "Parallel",
      "Branches": [
        {
          "StartAt": "EventBridge PutEvents",
          "States": {
            "EventBridge PutEvents": {
              "Type": "Task",
              "Resource": "arn:aws:states:::aws-sdk:eventbridge:putEvents",
              "Parameters": {
                "Entries": [
                  {
                    "Detail.$": "$",
                    "DetailType.$": "States.Format('MDM_{}', $.metadata.eventName)",
                    "EventBusName": "arn:aws:events:eu-north-1:260244973671:event-bus/cas-domain-bus",
                    "Source": "Informatica MDM"
                  }
                ]
              },
              "End": true,
              "Retry": [
                {
                  "ErrorEquals": [
                    "States.ALL"
                  ],
                  "BackoffRate": 3,
                  "IntervalSeconds": 30,
                  "MaxAttempts": 5
                }
              ]
            }
          }
        },
        {
          "StartAt": "EventBridge PutEvents",
          "States": {
            "EventBridge PutEvents": {
              "Type": "Task",
              "Resource": "arn:aws:states:::aws-sdk:eventbridge:putEvents",
              "Parameters": {
                "Entries": [
                  {
                    "Detail.$": "$",
                    "DetailType.$": "States.Format('MDM_{}', $.metadata.eventName)",
                    "EventBusName": "arn:aws:events:eu-north-1:762355295099:event-bus/pci-domain-bus",
                    "Source": "Informatica MDM"
                  }
                ]
              },
              "End": true,
              "Retry": [
                {
                  "ErrorEquals": [
                    "States.ALL"
                  ],
                  "BackoffRate": 3,
                  "IntervalSeconds": 30,
                  "MaxAttempts": 5
                }
              ]
            }
          }
        },
        {
          "StartAt": "EventBridge PutEvents",
          "States": {
            "EventBridge PutEvents": {
              "Type": "Task",
              "Resource": "arn:aws:states:::aws-sdk:eventbridge:putEvents",
              "Parameters": {
                "Entries": [
                  {
                    "Detail.$": "$",
                    "DetailType.$": "States.Format('MDM_{}', $.metadata.eventName)",
                    "EventBusName": "arn:aws:events:eu-north-1:260244973671:event-bus/cas-domain-bus",
                    "Source": "Informatica MDM"
                  }
                ]
              },
              "End": true,
              "Retry": [
                {
                  "ErrorEquals": [
                    "States.ALL"
                  ],
                  "BackoffRate": 3,
                  "IntervalSeconds": 30,
                  "MaxAttempts": 5
                }
              ]
            }
          }
        }
      ],
      "End": true
    }
  }
  EOF
}
*/

#
# Event Bridge
#

resource "aws_cloudwatch_event_bus" "mdm_publishing_event_bus" {
  name = "mdmpublishupdates"
}

resource "aws_cloudwatch_event_rule" "mdm_publishing_event_rule" {
  name           = "AllMessages"
  event_bus_name = aws_cloudwatch_event_bus.mdm_publishing_event_bus.arn
  event_pattern  = jsonencode({ source = ["Informatica MDM"] })
}

resource "aws_cloudwatch_event_target" "mdm_publishing_event_bus_targets" {
  arn            = aws_lambda_function.mdm_publishing_log_function.arn
  rule           = aws_cloudwatch_event_rule.mdm_publishing_event_rule.name
  event_bus_name = aws_cloudwatch_event_bus.mdm_publishing_event_bus.arn
}

#
# Lambda authorization function
#

resource "aws_lambda_permission" "allow_api" {
  statement_id  = "AllowAPIgatewayInvokation"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.mdm_publishing_authorizer_function.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.mdm_publishing_api_gateway.execution_arn}/authorizers/${aws_apigatewayv2_authorizer.mdm_publishing_authorizer.id}"
}

data "archive_file" "lambda_auth_zip" {
  type        = "zip"
  source_file = "../../external/lambda_function.py"
  output_path = "../../external/lambda_function.zip"
}

resource "aws_lambda_function" "mdm_publishing_authorizer_function" {
  filename         = data.archive_file.lambda_auth_zip.output_path
  function_name    = "MDMPublishEventAuthorizer"
  handler          = "lambda_function.lambda_handler"
  role             = aws_iam_role.role_for_mdmpublishing.arn
  source_code_hash = data.archive_file.lambda_auth_zip.output_base64sha256
  runtime          = "python3.11"
}

resource "aws_lambda_alias" "mdm_publishing_authorizer_function_alias" {
  name             = "testalias"
  description      = "a sample description"
  function_name    = aws_lambda_function.mdm_publishing_authorizer_function.function_name
  function_version = "$LATEST"
}


data "archive_file" "lambda_log_zip" {
  type        = "zip"
  source_file = "../../external/lambda_log.py"
  output_path = "../../external/lambda_log.zip"
}

resource "aws_lambda_function" "mdm_publishing_log_function" {
  filename         = data.archive_file.lambda_log_zip.output_path
  function_name    = "LogEventBridgeEvent"
  handler          = "lambda_log.lambda_handler"
  role             = aws_iam_role.role_for_mdmpublishing.arn
  source_code_hash = data.archive_file.lambda_log_zip.output_base64sha256
  runtime          = "python3.11"
}

resource "aws_lambda_alias" "mdm_publishing_log_function_alias" {
  name             = "testalias"
  description      = "a sample description"
  function_name    = aws_lambda_function.mdm_publishing_log_function.function_name
  function_version = "$LATEST"
}

#
# IAM & Secret Management
#

resource "aws_iam_role" "role_for_mdmpublishing" {
  name               = "role_for_mdmpublishing"
  assume_role_policy = data.aws_iam_policy_document.assume_role.json
}

resource "aws_iam_role_policy_attachment" "role-policy-attach" {
  role       = aws_iam_role.role_for_mdmpublishing.name
  policy_arn = data.aws_iam_policy.AmazonAPIGatewayPushToCloudWatchLogs.arn
}

resource "aws_iam_role_policy_attachment" "role-policy-attach2" {
  role       = aws_iam_role.role_for_mdmpublishing.name
  policy_arn = data.aws_iam_policy.AmazonEventBridgeFullAccess.arn
}

resource "aws_iam_role_policy_attachment" "role-policy-attach3" {
  role       = aws_iam_role.role_for_mdmpublishing.name
  policy_arn = aws_iam_policy.GetSecretValuePolicy.arn
}

resource "aws_iam_role_policy_attachment" "role-policy-attach4" {
  role       = aws_iam_role.role_for_mdmpublishing.name
  policy_arn = data.aws_iam_policy.AmazonStepFunctionFullAccess.arn
}

data "aws_iam_policy" "AmazonAPIGatewayPushToCloudWatchLogs" {
  arn = "arn:aws:iam::aws:policy/service-role/AmazonAPIGatewayPushToCloudWatchLogs"
}

data "aws_iam_policy" "AmazonEventBridgeFullAccess" {
  arn = "arn:aws:iam::aws:policy/AmazonEventBridgeFullAccess"
}

resource "aws_iam_policy" "GetSecretValuePolicy" {
  name   = "GetSecretValuePolicy"
  policy = jsonencode({
    "Version" : "2012-10-17",
    "Statement" : [
      {
        "Effect" : "Allow",
        "Action" : [
          "secretsmanager:GetSecretValue"
        ],
        "Resource" : aws_secretsmanager_secret.oauth_publishing_api_access_secret.id
      }
    ]
  })
}

data "aws_iam_policy" "AmazonStepFunctionFullAccess" {
  arn = "arn:aws:iam::aws:policy/AWSStepFunctionsFullAccess"
}

data "aws_iam_policy_document" "assume_role" {
  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com", "apigateway.amazonaws.com", "states.amazonaws.com"]
    }

    actions = ["sts:AssumeRole"]
  }
}

resource "aws_secretsmanager_secret" "oauth_publishing_api_access_secret" {
  name = "idmc/mdm/oauth-publishing-api-access"
}

resource "aws_secretsmanager_secret_version" "secret_val" {
  secret_id     = aws_secretsmanager_secret.oauth_publishing_api_access_secret.id
  secret_string = jsonencode({
    "clientid" : "${var.InformaticaMDMClientId}", "secret" : "${random_password.secret.result}"
  })
}

resource "random_password" "secret" {
  length           = 16
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}
