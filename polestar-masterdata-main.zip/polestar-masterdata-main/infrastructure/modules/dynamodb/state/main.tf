# Configuration for Terraform state lock table.
#
# See: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dynamodb_table

resource "aws_dynamodb_table" "terraform_state_lock" {
  #checkov:skip=CKV_AWS_119:Not necessary to use customer-managed KMS key for this
  name         = var.name
  hash_key     = var.hash_key
  billing_mode = "PAY_PER_REQUEST"

  attribute {
    name = var.hash_key
    type = "S"
  }

  point_in_time_recovery {
    enabled = true
  }

  #replica {
  #  region_name = var.region_primary
  #}

  #replica {
  #  region_name = var.region_secondary
  #}
}
