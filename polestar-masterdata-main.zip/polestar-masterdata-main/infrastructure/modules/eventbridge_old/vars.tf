variable "env" {
  description = "AWS Enviroment"
  type        = string
  default     = "demo"

}
variable "region" {
  description = "AWS region"
  type        = string
}

variable "account_id" {
  default   = ""
  sensitive = true
}

variable "project" {
  description = "project name"
  type        = string
  default     = "masterdata"
}

variable "InformaticaMDMClientId" {
  default   = ""
  sensitive = true
}

variable "event_rules" {
  description = "An object for configuring the event rules on the event bus"
  type        = map(object({
    name   = string
    detail = map(any)
  }))
}

variable "event_rule_function_mappings" {
  description = "An object for configuring the targets on the event bus"
  type        = list(object({
    rule_name     = string
    function_name = string
  }))
}