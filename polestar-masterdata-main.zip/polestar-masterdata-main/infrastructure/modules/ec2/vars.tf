variable "env" {
  description = "AWS Enviroment"
  type        = string
  default     = "demo"

}
variable "region" {
  description = "AWS region"
  type        = string
}

variable "ami" {
  description = "Amazon Machine Image"
  type        = string
}

variable "instance_type" {
  description = "Instance Type"
  type        = string
}

variable "subnet_id" {
  description = "Subnet ID"
  type        = string
}

variable "availability_zone" {
  description = "Availability zone"
  type        = string
}

variable "vpc_security_groups" {
  description = "VPC Security Groups"
  type        = list(string)
}

variable "cpu_core_count" {
  description = "Cpu cores"
  type        = number
  default     = 2
}
