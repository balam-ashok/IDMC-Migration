variable "region" {
  description = "AWS region"
  type        = string
}
variable "secret_manager_name" {
  description = "secret manager name"
  type        = string
}
variable "role_name" {
  description = "role name"
  type        = string
}
variable "odp_account_ids" {
  description = "ODP Account IDs"
  type        = map(string)
}
