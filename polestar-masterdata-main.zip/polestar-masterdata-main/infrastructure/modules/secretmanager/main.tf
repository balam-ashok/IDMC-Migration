resource "aws_secretsmanager_secret" "my_secret" {
  name        = var.secret_manager_name
  description = "Secret for cross account access"
}

############################
# IAM ROLE (CROSS ACCOUNT)
############################
resource "aws_iam_role" "cross_account_role" {
  name = var.role_name

  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Principal = {
          AWS = [
            for acc in values(var.odp_account_ids) :
            "arn:aws:iam::${acc}:root"
          ]
        },
        Action = "sts:AssumeRole"
      }
    ]
  })
}

############################
# IAM POLICY (READ SECRET)
############################
resource "aws_iam_policy" "secret_read_policy" {
  name = "SecretsManagerReadPolicy"

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret"
        ],
        Resource = aws_secretsmanager_secret.my_secret.arn
      }
    ]
  })
}

############################
# ATTACH POLICY TO ROLE
############################
resource "aws_iam_role_policy_attachment" "attach_policy" {
  role       = aws_iam_role.cross_account_role.name
  policy_arn = aws_iam_policy.secret_read_policy.arn
}



