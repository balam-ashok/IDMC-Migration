variable "env" {
  description = "AWS Enviroment"
  type        = string
  default     = "demo"

}
variable "region" {
  description = "AWS region"
  type        = string
}

variable "account_id" {
  default   = ""
  sensitive = true
}

variable "plm_sns_topic" {
  description = "Connection to SNS topic of PLM"
  type        = string
}

variable "s3_bucket" {
  description = "S3 Bucket name"
  type        = string
}

variable "s3_plm_json_path" {
  description = "S3 PLM JSON folder to store the files to"
  type        = string
}
