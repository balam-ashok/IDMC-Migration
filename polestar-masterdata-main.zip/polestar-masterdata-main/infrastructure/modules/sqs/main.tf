#
# provider to manage SNS topics
#

provider "aws" {
  alias  = "plm_partmaster"
  region = "eu-central-1"
}

#
# SQS Queue
#

data "aws_iam_policy_document" "sqs-queue-policy" {
  policy_id = "arn:aws:sqs:${var.region}:${var.account_id}:mdm-plm-sns-queue/SQSDefaultPolicy"

  statement {
    sid    = "topic-subscription-arn:${var.plm_sns_topic}"
    effect = "Allow"

    principals {
      type        = "AWS"
      identifiers = ["*"]
    }

    actions = [
      "SQS:SendMessage",
    ]

    resources = [
      "arn:aws:sqs:${var.region}:${var.account_id}:mdm-plm-sns-queue",
    ]

    condition {
      test     = "ArnLike"
      variable = "aws:SourceArn"

      values = [
        var.plm_sns_topic,
      ]
    }
  }
}

resource "aws_sqs_queue" "mdm_plm_sns_queue" {
  name                       = "mdm-plm-sns-queue"
  message_retention_seconds  = 600
  visibility_timeout_seconds = 600
  policy                     = data.aws_iam_policy_document.sqs-queue-policy.json
  
  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.mdm_plm_sns_queue_deadletter.arn
    maxReceiveCount     = 3  # After 2 failed attempts, the message goes to the DLQ
  })
}

resource "aws_sns_topic_subscription" "mdm_plm_sns_subscription" {
  provider = aws.plm_partmaster
  topic_arn = var.plm_sns_topic
  protocol  = "sqs"
  endpoint  = aws_sqs_queue.mdm_plm_sns_queue.arn
}

resource "aws_lambda_event_source_mapping" "sqs_trigger" {
  event_source_arn = aws_sqs_queue.mdm_plm_sns_queue.arn
  function_name    = aws_lambda_function.mdm_sqsplmjson_function.arn
  batch_size       = 5
}

# Define the dead-letter queue
resource "aws_sqs_queue" "mdm_plm_sns_queue_deadletter" {
  name = "mdm-plm-sns-queue-deadletter"
  message_retention_seconds  = 1209600
  visibility_timeout_seconds = 43200  
}

resource "aws_sqs_queue_redrive_allow_policy" "mdm_plm_sns_queue_deadletter_redrive_allow_policy" {
  queue_url = aws_sqs_queue.mdm_plm_sns_queue_deadletter.id

  redrive_allow_policy = jsonencode({
    redrivePermission = "byQueue",
    sourceQueueArns   = [aws_sqs_queue.mdm_plm_sns_queue.arn]
  })
}

#
# Lambda S3 file creation function
#

resource "aws_lambda_permission" "allow_sqs" {
  statement_id  = "AllowSQSInvocation"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.mdm_sqsplmjson_function.function_name
  principal     = "sqs.amazonaws.com"
  source_arn    = aws_sqs_queue.mdm_plm_sns_queue.arn
}

data "archive_file" "lambda_sqsplmjson_zip" {
  type        = "zip"
  source_file = "../../external/lambda_function_plmintegration.py"
  output_path = "../../external/lambda_function_plmintegration.zip"
}

resource "aws_lambda_function" "mdm_sqsplmjson_function" {
  filename         = data.archive_file.lambda_sqsplmjson_zip.output_path
  function_name    = "CreatePlmJsonFileFromSqs"
  handler          = "lambda_function_plmintegration.lambda_handler"
  role             = aws_iam_role.role_for_mdmsqsintegration.arn
  source_code_hash = data.archive_file.lambda_sqsplmjson_zip.output_base64sha256
  runtime          = "python3.11"
  depends_on       = [aws_cloudwatch_log_group.mdm_sqsplmjson_function_log_group]
  
  environment {
    variables = {
      S3_BUCKET     = var.s3_bucket
      PLM_JSON_PATH = var.s3_plm_json_path
    }
  }
}

resource "aws_cloudwatch_log_group" "mdm_sqsplmjson_function_log_group" {
  name              = "/aws/lambda/CreatePlmJsonFileFromSqs"
  retention_in_days = 7
}

#
# IAM & Secret Management
#

resource "aws_iam_role" "role_for_mdmsqsintegration" {
  name               = "role_for_mdmsqsintegration"
  assume_role_policy = data.aws_iam_policy_document.assume_role.json
}

resource "aws_iam_role_policy_attachment" "role-policy-attach-s3" {
  role       = aws_iam_role.role_for_mdmsqsintegration.name
  policy_arn = data.aws_iam_policy.AmazonS3FullAccess.arn
}

resource "aws_iam_role_policy_attachment" "role-policy-attach-sqs" {
  role       = aws_iam_role.role_for_mdmsqsintegration.name
  policy_arn = data.aws_iam_policy.AmazonSQSFullAccess.arn
}

resource "aws_iam_role_policy_attachment" "role-policy-attach-log" {
  role       = aws_iam_role.role_for_mdmsqsintegration.name
  policy_arn = data.aws_iam_policy.AWSLambdaBasicExecutionRole.arn
}

data "aws_iam_policy_document" "assume_role" {
  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com", "apigateway.amazonaws.com", "states.amazonaws.com"]
    }

    actions = ["sts:AssumeRole"]
  }
}

data "aws_iam_policy" "AmazonS3FullAccess" {
  arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}

data "aws_iam_policy" "AmazonSQSFullAccess" {
  arn = "arn:aws:iam::aws:policy/AmazonSQSFullAccess"
}

data "aws_iam_policy" "AWSLambdaBasicExecutionRole" {
  arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}
