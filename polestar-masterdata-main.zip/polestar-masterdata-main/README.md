# polestar-masterdata
Version control of assets pertaining to the Polestar Master Data solution
